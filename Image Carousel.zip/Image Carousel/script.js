const carouselSlide = document.querySelector('.carousel-slide');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');

let slideIndex = 0;

function showSlides(index) {
  const slides = document.querySelectorAll('.carousel-slide img');
  if (index >= slides.length) {
    slideIndex = 0;
  } else if (index < 0) {
    slideIndex = slides.length - 1;
  }

  carouselSlide.style.transform = `translateX(${-slideIndex * 100}%)`;
}

function nextSlide() {
  slideIndex++;
  showSlides(slideIndex);
}

function prevSlide() {
  slideIndex--;
  showSlides(slideIndex);
}

nextBtn.addEventListener('click', nextSlide);
prevBtn.addEventListener('click', prevSlide);

// Auto play slides
setInterval(nextSlide, 3000); // Change slide every 3 seconds (adjust as needed)
